$csPath = "$env:TEMP\Browsium.cs"
$exePath = "$env:TEMP\Browsium.exe"

$cscPaths = @(
    "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe",
    "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\csc.exe"
)

$cscExe = $null
foreach ($path in $cscPaths) {
    if (Test-Path $path) {
        $cscExe = $path
        break
    }
}

if (-not $cscExe) { exit }

$searchRoots = @(
    "${env:ProgramFiles(x86)}\Microsoft",
    "$env:ProgramFiles\Microsoft",
    "$env:LocalAppData\Microsoft",
    "$env:USERPROFILE\.nuget\packages"
)

$wv2WinForms = $null
$wv2Core = $null

foreach ($root in $searchRoots) {
    if (Test-Path $root) {
        if (-not $wv2WinForms) {
            $found = Get-ChildItem -Path $root -Filter "Microsoft.Web.WebView2.WinForms.dll" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($found) { $wv2WinForms = $found.FullName }
        }
        if (-not $wv2Core) {
            $foundCore = Get-ChildItem -Path $root -Filter "Microsoft.Web.WebView2.Core.dll" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($foundCore) { $wv2Core = $foundCore.FullName }
        }
    }
}

if (-not $wv2WinForms -or -not $wv2Core) {
    $nugetDir = "$env:TEMP\WV2Pkg"
    New-Item -ItemType Directory -Force -Path $nugetDir | Out-Null
    $zipFile = "$nugetDir\wv2.zip"
    Invoke-WebRequest -Uri "https://www.nuget.org/api/v2/package/Microsoft.Web.WebView2/1.0.2592.51" -OutFile $zipFile -UseBasicParsing
    Expand-Archive -Path $zipFile -DestinationPath $nugetDir -Force
    $wv2WinForms = "$nugetDir\lib\net462\Microsoft.Web.WebView2.WinForms.dll"
    $wv2Core = "$nugetDir\lib\net462\Microsoft.Web.WebView2.Core.dll"
    $arch = if ([Environment]::Is64BitProcess) { "win-x64" } else { "win-x86" }
    Copy-Item "$nugetDir\runtimes\$arch\native\WebView2Loader.dll" "$env:TEMP\WebView2Loader.dll" -Force
} else {
    $dllDir = Split-Path $wv2WinForms
    $loader = Get-ChildItem -Path (Split-Path $dllDir -Parent) -Filter "WebView2Loader.dll" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($loader) {
        Copy-Item $loader.FullName "$env:TEMP\WebView2Loader.dll" -Force
    }
}

Copy-Item $wv2WinForms "$env:TEMP\Microsoft.Web.WebView2.WinForms.dll" -Force
Copy-Item $wv2Core "$env:TEMP\Microsoft.Web.WebView2.Core.dll" -Force

$csCode = @'
using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;
using Microsoft.Web.WebView2.Core;

public class Browsium : Form {
    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);

    private TableLayoutPanel navLayout;
    private WebView2 webView;
    private TextBox urlBox;
    private Button btnBack;
    private Button btnForward;
    private Button btnGo;
    private Button btnMenu;
    private ContextMenuStrip menuStrip;

    public Browsium() {
        this.Text = "Browsium";
        this.Size = new Size(1180, 760);
        this.MinimumSize = new Size(640, 480);
        this.StartPosition = FormStartPosition.CenterScreen;
        this.FormBorderStyle = FormBorderStyle.Sizable;
        this.MaximizeBox = true;
        this.MinimizeBox = true;
        this.BackColor = Color.FromArgb(236, 233, 216);

        this.HandleCreated += (s, e) => {
            try {
                int policy = 1;
                DwmSetWindowAttribute(this.Handle, 2, ref policy, sizeof(int));
            } catch { }
        };

        navLayout = new TableLayoutPanel();
        navLayout.Dock = DockStyle.Top;
        navLayout.Height = 40;
        navLayout.ColumnCount = 5;
        navLayout.RowCount = 1;
        navLayout.BackColor = Color.FromArgb(236, 233, 216);
        navLayout.Padding = new Padding(4, 5, 4, 5);
        navLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 68F));
        navLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 74F));
        navLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        navLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 54F));
        navLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 72F));

        btnBack = CreateNavButton("Voltar");
        btnBack.Click += (s, e) => { if (webView.CoreWebView2 != null && webView.CanGoBack) webView.GoBack(); };

        btnForward = CreateNavButton("Avancar");
        btnForward.Click += (s, e) => { if (webView.CoreWebView2 != null && webView.CanGoForward) webView.GoForward(); };

        urlBox = new TextBox();
        urlBox.Text = "https://www.google.com";
        urlBox.Font = new Font("Tahoma", 9.5f);
        urlBox.Dock = DockStyle.Fill;
        urlBox.Margin = new Padding(3, 3, 3, 2);
        urlBox.KeyDown += (s, e) => {
            if (e.KeyCode == Keys.Enter) {
                e.SuppressKeyPress = true;
                Navigate(urlBox.Text);
            }
        };

        btnGo = CreateNavButton("Ir");
        btnGo.Click += (s, e) => Navigate(urlBox.Text);

        menuStrip = new ContextMenuStrip();
        menuStrip.Items.Add("Recarregar Pagina", null, (s, e) => { if (webView.CoreWebView2 != null) webView.Reload(); });
        menuStrip.Items.Add("Tela Cheia (F11)", null, (s, e) => ToggleFullScreen());
        menuStrip.Items.Add("Ferramentas de Desenvolvedor (F12)", null, (s, e) => { if (webView.CoreWebView2 != null) webView.CoreWebView2.OpenDevToolsWindow(); });
        menuStrip.Items.Add("Configuracoes do Motor", null, (s, e) => Navigate("edge://settings"));

        btnMenu = CreateNavButton("Menu");
        btnMenu.Click += (s, e) => menuStrip.Show(btnMenu, new Point(0, btnMenu.Height));

        navLayout.Controls.Add(btnBack, 0, 0);
        navLayout.Controls.Add(btnForward, 1, 0);
        navLayout.Controls.Add(urlBox, 2, 0);
        navLayout.Controls.Add(btnGo, 3, 0);
        navLayout.Controls.Add(btnMenu, 4, 0);

        webView = new WebView2();
        webView.Dock = DockStyle.Fill;
        webView.CoreWebView2InitializationCompleted += (s, e) => {
            if (e.IsSuccess) {
                webView.CoreWebView2.SourceChanged += (sender, args) => {
                    urlBox.Text = webView.Source.ToString();
                };
                webView.CoreWebView2.Navigate("https://www.google.com");
            }
        };

        this.Controls.Add(webView);
        this.Controls.Add(navLayout);

        this.Shown += async (s, e) => {
            await webView.EnsureCoreWebView2Async(null);
        };
    }

    private Button CreateNavButton(string text) {
        Button b = new Button();
        b.Text = text;
        b.Font = new Font("Tahoma", 8.5f);
        b.Dock = DockStyle.Fill;
        b.Margin = new Padding(2, 1, 2, 1);
        b.BackColor = Color.FromArgb(245, 244, 234);
        b.FlatStyle = FlatStyle.Standard;
        return b;
    }

    private void ToggleFullScreen() {
        if (this.FormBorderStyle != FormBorderStyle.None) {
            this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;
        } else {
            this.FormBorderStyle = FormBorderStyle.Sizable;
            this.WindowState = FormWindowState.Normal;
            int policy = 1;
            DwmSetWindowAttribute(this.Handle, 2, ref policy, sizeof(int));
        }
    }

    private void Navigate(string rawUrl) {
        string url = rawUrl.Trim();
        if (!url.StartsWith("http://") && !url.StartsWith("https://") && !url.StartsWith("edge://")) {
            url = "https://" + url;
        }
        urlBox.Text = url;
        if (webView.CoreWebView2 != null) {
            webView.CoreWebView2.Navigate(url);
        }
    }

    [STAThread]
    public static void Main() {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new Browsium());
    }
}
'@

$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($csPath, $csCode, $utf8NoBom)

& $cscExe /target:winexe /out:$exePath /reference:System.dll /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:"$env:TEMP\Microsoft.Web.WebView2.WinForms.dll" /reference:"$env:TEMP\Microsoft.Web.WebView2.Core.dll" $csPath

if (Test-Path $exePath) {
    Start-Process $exePath
}